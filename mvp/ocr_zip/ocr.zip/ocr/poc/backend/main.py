import os
import io
import base64
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from dotenv import load_dotenv
from openai import OpenAI
from pdf2image import convert_from_bytes  # pip install pdf2image
from PIL import Image

# Load environment variables
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY missing in environment (.env)")

client = OpenAI(api_key=OPENAI_API_KEY)

app = FastAPI(title="OCR via OpenAI")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def do_ocr_on_image(img_bytes: bytes, mime_type: str) -> str:
    """Send image to OpenAI OCR endpoint and return extracted text."""
    img_b64 = base64.b64encode(img_bytes).decode("utf-8")
    data_url = f"data:{mime_type};base64,{img_b64}"

    messages = [
        {"role": "system", "content": "You are an OCR engine. Extract text accurately."},
        {"role": "user", "content": [
            {"type": "text", "text": "Extract the text from this image"},
            {"type": "image_url", "image_url": {"url": data_url}}
        ]}
    ]

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=messages,
        max_tokens=4000,  # increase if expecting large text
    )

    # Use .content instead of indexing, to avoid 'ChatCompletionMessage not subscriptable' errors
    return response.choices[0].message.content


@app.post("/ocr")
async def ocr_endpoint(file: UploadFile = File(...)):
    """OCR endpoint for images and PDFs."""
    contents = await file.read()
    filename = file.filename.lower()

    if filename.endswith(".pdf"):
        try:
            # Convert PDF to images
            pages = convert_from_bytes(contents, poppler_path=r"D:\poppler-25.11.0\Library\bin")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"PDF processing failed: {str(e)}")

        extracted_text = ""
        for idx, page in enumerate(pages):
            buf = io.BytesIO()
            page.save(buf, format="JPEG")
            img_bytes = buf.getvalue()

            text = do_ocr_on_image(img_bytes, "image/jpeg")
            extracted_text += f"\n\n--- Page {idx+1} ---\n{text}"

        return {"ok": True, "ocr_text": extracted_text}

    else:
        # Assume image
        mime = file.content_type or "image/jpeg"
        text = do_ocr_on_image(contents, mime)
        return {"ok": True, "ocr_text": text}


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
